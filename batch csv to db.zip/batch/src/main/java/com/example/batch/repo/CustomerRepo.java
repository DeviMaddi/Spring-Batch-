package com.example.batch.repo;
import com.example.batch.entity.*;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;



public interface CustomerRepo extends JpaRepository<Customer,Serializable> {

}
